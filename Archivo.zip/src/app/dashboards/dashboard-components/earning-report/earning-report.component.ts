import { Component } from '@angular/core';
@Component({
    selector: 'earning-report',
	templateUrl: './earning-report.component.html' 
})
export class EarningComponent {
	
	constructor() {		
	}

}