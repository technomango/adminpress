import { Component } from '@angular/core';
@Component({
    selector: 'project',
	templateUrl: './project.component.html' 
})
export class ProjectComponent {
	
	constructor() {		
	}

}