import { Component} from '@angular/core';
@Component({
	templateUrl: 'timeline.component.html' 
})
export class TimelineComponent {
	
}